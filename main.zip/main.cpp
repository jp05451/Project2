﻿#include <iostream>
//#include "ChessBoard.h"
#include"Viewer.h"
int main()
{
                Viewer v;
                v.GameStart();
   // ChessBoard board;
    //std::cout << board;
}

